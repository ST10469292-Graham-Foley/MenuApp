Link to GitHub:

https://github.com/IIEWFL/imad5112-assignment-1-ST10469292-Graham-Foley  (didn't see repository when making app)
https://github.com/ST10469292-Graham-Foley/MenuApp  (has commits)


YouTube Video:

https://youtu.be/AN-Xfih0vIE


Screenshots:

(in folder)


Report:

The purpose of this app is to be an easy-to-use application that suggests meal options based on the time of day for those who do not want to choose a meal themselves.

The design of the app was to be made simple and easy to understand.

I used GitHub to auto build my workflow 


Reference:

amirisback, frogoboxbot and dependabot[bot] (eds.) (2022) Automated-build-android-app-with-github-action - github marketplace, GitHub. Available at: https://github.com/marketplace/actions/automated-build-android-app-with-github-action (Accessed: 02 April 2025). 